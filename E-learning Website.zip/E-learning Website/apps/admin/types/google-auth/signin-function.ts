export interface TGoogleSignInFunction {
  clientId: string;
  credential: string;
}