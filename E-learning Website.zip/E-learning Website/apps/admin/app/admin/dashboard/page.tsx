import { SignOutButton } from "./_components/button";

export default function AdminDashboardPage() {
  return (
    <div>
      <p>Hello Admin</p>
      <SignOutButton />
    </div>
  );
}