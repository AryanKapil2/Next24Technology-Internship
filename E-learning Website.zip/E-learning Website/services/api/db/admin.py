from django.contrib import admin
from db.models import User

# Now register the new UserModelAdmin...

