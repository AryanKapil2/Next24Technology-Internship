export function ApplicationLayout({ children }: { children: React.ReactNode }) {
  return <body className="h-screen w-full light">{children}</body>;
}
