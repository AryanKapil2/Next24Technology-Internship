export * from "@repo/tailwind-config/tw-config";

/**
 * Author: sidarth-23
 * Date: 2023-02-15
 * 
 * Any changes you want, make it in the tailwind config package so that it is consistent across all the apps
 */