export interface TForgotPasswordSuccessResponse {
  message: string;
}
export interface TForgotPasswordErrorResponse {
  non_field_errors: string[];
}